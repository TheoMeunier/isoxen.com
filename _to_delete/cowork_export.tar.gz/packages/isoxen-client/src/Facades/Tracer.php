<?php

namespace Isoxen\Client\Facades;

use Illuminate\Support\Facades\Facade;
use Isoxen\Client\Support\SpanBuilder;
use OpenTelemetry\API\Trace\SpanInterface;
use OpenTelemetry\Context\Context;
use OpenTelemetry\Context\ContextInterface;
use OpenTelemetry\Context\ScopeInterface;

/**
 * @method static bool traceStarted()
 * @method static string|null traceId()
 * @method static SpanInterface activeSpan()
 * @method static ScopeInterface|null activeScope()
 * @method static ContextInterface currentContext()
 * @method static array propagationHeaders(?ContextInterface $context = null)
 * @method static Context|null extractContextFromPropagationHeaders(array $headers)
 * @method static SpanBuilder newSpan(string $name)
 * @method static void updateLogContext()
 * @method static void terminateActiveSpansUpToRoot(?SpanInterface $root = null)
 */
class Tracer extends Facade
{
    protected static function getFacadeAccessor(): string
    {
        return \Isoxen\Client\Tracer::class;
    }
}
