<?php

namespace Isoxen\Client\Instrumentation;

use Isoxen\Client\Facades\Tracer;
use Isoxen\Client\Instrumentation\Support\InstrumentationUtilities;
use Isoxen\Client\SpanType;
use Livewire\Component;
use Livewire\LivewireManager;
use OpenTelemetry\API\Trace\SpanInterface;
use OpenTelemetry\Context\ScopeInterface;
use WeakMap;

class LivewireInstrumentation implements Instrumentation
{
    use InstrumentationUtilities;

    /**
     * @var WeakMap<Component, array{0: SpanInterface, 1: ScopeInterface}>
     */
    protected WeakMap $components;

    public function register(array $options): void
    {
        $this->components = new WeakMap;

        if (! class_exists(LivewireManager::class)) {
            return;
        }

        $this->callAfterResolving(LivewireManager::class, $this->registerLivewire(...));
    }

    protected function registerLivewire(LivewireManager $livewireManager): void
    {
        $livewireManager->listen('mount', function (Component $component) {
            if (! Tracer::traceStarted()) {
                return;
            }

            $this->traceComponent($component);
        });

        $livewireManager->listen('hydrate', function (Component $component) {
            if (! Tracer::traceStarted()) {
                return;
            }

            $this->traceComponent($component);
        });

        $livewireManager->listen('dehydrate', function (Component $component) {
            $trace = $this->components[$component] ?? null;

            if ($trace === null) {
                return;
            }

            [$span, $scope] = $trace;

            $scope->detach();
            $span->end();
        });
    }

    protected function traceComponent(Component $component): void
    {
        $span = Tracer::newSpan('livewire component')
            ->setAttribute(SpanType::ATTRIBUTE, SpanType::Livewire->value)
            ->setAttributes([
                'component.name' => $component->getName(),
                'component.id' => $component->getId(),
            ])
            ->start();
        $scope = $span->activate();

        $this->components[$component] = [$span, $scope];
    }
}
