import Controllers from './Controllers'

const Auth = {
    Controllers: Object.assign(Controllers, Controllers),
}

export default Auth