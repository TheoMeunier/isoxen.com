import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Watch\Ingestion\Controllers\IngestLogsController::store
* @see Watch/Ingestion/Controllers/IngestLogsController.php:16
* @route '/v1/logs'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/v1/logs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Watch\Ingestion\Controllers\IngestLogsController::store
* @see Watch/Ingestion/Controllers/IngestLogsController.php:16
* @route '/v1/logs'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Watch\Ingestion\Controllers\IngestLogsController::store
* @see Watch/Ingestion/Controllers/IngestLogsController.php:16
* @route '/v1/logs'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Watch\Ingestion\Controllers\IngestLogsController::store
* @see Watch/Ingestion/Controllers/IngestLogsController.php:16
* @route '/v1/logs'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Watch\Ingestion\Controllers\IngestLogsController::store
* @see Watch/Ingestion/Controllers/IngestLogsController.php:16
* @route '/v1/logs'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const IngestLogsController = { store }

export default IngestLogsController