import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Watch\Ingestion\Controllers\IngestMetricsController::store
* @see Watch/Ingestion/Controllers/IngestMetricsController.php:16
* @route '/v1/metrics'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/v1/metrics',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Watch\Ingestion\Controllers\IngestMetricsController::store
* @see Watch/Ingestion/Controllers/IngestMetricsController.php:16
* @route '/v1/metrics'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Watch\Ingestion\Controllers\IngestMetricsController::store
* @see Watch/Ingestion/Controllers/IngestMetricsController.php:16
* @route '/v1/metrics'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Watch\Ingestion\Controllers\IngestMetricsController::store
* @see Watch/Ingestion/Controllers/IngestMetricsController.php:16
* @route '/v1/metrics'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Watch\Ingestion\Controllers\IngestMetricsController::store
* @see Watch/Ingestion/Controllers/IngestMetricsController.php:16
* @route '/v1/metrics'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const IngestMetricsController = { store }

export default IngestMetricsController