import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Watch\Ingestion\Controllers\IngestTracesController::store
* @see Watch/Ingestion/Controllers/IngestTracesController.php:16
* @route '/v1/traces'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/v1/traces',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Watch\Ingestion\Controllers\IngestTracesController::store
* @see Watch/Ingestion/Controllers/IngestTracesController.php:16
* @route '/v1/traces'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Watch\Ingestion\Controllers\IngestTracesController::store
* @see Watch/Ingestion/Controllers/IngestTracesController.php:16
* @route '/v1/traces'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Watch\Ingestion\Controllers\IngestTracesController::store
* @see Watch/Ingestion/Controllers/IngestTracesController.php:16
* @route '/v1/traces'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Watch\Ingestion\Controllers\IngestTracesController::store
* @see Watch/Ingestion/Controllers/IngestTracesController.php:16
* @route '/v1/traces'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const IngestTracesController = { store }

export default IngestTracesController