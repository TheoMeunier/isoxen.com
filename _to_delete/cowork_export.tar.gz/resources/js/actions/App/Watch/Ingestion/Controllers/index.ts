import IngestTracesController from './IngestTracesController'
import IngestMetricsController from './IngestMetricsController'
import IngestLogsController from './IngestLogsController'

const Controllers = {
    IngestTracesController: Object.assign(IngestTracesController, IngestTracesController),
    IngestMetricsController: Object.assign(IngestMetricsController, IngestMetricsController),
    IngestLogsController: Object.assign(IngestLogsController, IngestLogsController),
}

export default Controllers