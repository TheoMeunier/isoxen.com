import Controllers from './Controllers'

const Ingestion = {
    Controllers: Object.assign(Controllers, Controllers),
}

export default Ingestion