import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Watch\Projects\Controllers\CreateProjectController::execute
* @see Watch/Projects/Controllers/CreateProjectController.php:23
* @route '/projects'
*/
export const execute = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: execute.url(options),
    method: 'post',
})

execute.definition = {
    methods: ["post"],
    url: '/projects',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Watch\Projects\Controllers\CreateProjectController::execute
* @see Watch/Projects/Controllers/CreateProjectController.php:23
* @route '/projects'
*/
execute.url = (options?: RouteQueryOptions) => {
    return execute.definition.url + queryParams(options)
}

/**
* @see \App\Watch\Projects\Controllers\CreateProjectController::execute
* @see Watch/Projects/Controllers/CreateProjectController.php:23
* @route '/projects'
*/
execute.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: execute.url(options),
    method: 'post',
})

/**
* @see \App\Watch\Projects\Controllers\CreateProjectController::execute
* @see Watch/Projects/Controllers/CreateProjectController.php:23
* @route '/projects'
*/
const executeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: execute.url(options),
    method: 'post',
})

/**
* @see \App\Watch\Projects\Controllers\CreateProjectController::execute
* @see Watch/Projects/Controllers/CreateProjectController.php:23
* @route '/projects'
*/
executeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: execute.url(options),
    method: 'post',
})

execute.form = executeForm

const CreateProjectController = { execute }

export default CreateProjectController