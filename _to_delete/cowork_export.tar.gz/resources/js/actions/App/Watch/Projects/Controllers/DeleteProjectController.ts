import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Watch\Projects\Controllers\DeleteProjectController::execute
* @see Watch/Projects/Controllers/DeleteProjectController.php:22
* @route '/projects/{project}'
*/
export const execute = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: execute.url(args, options),
    method: 'delete',
})

execute.definition = {
    methods: ["delete"],
    url: '/projects/{project}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Watch\Projects\Controllers\DeleteProjectController::execute
* @see Watch/Projects/Controllers/DeleteProjectController.php:22
* @route '/projects/{project}'
*/
execute.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { project: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            project: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        project: typeof args.project === 'object'
        ? args.project.id
        : args.project,
    }

    return execute.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Watch\Projects\Controllers\DeleteProjectController::execute
* @see Watch/Projects/Controllers/DeleteProjectController.php:22
* @route '/projects/{project}'
*/
execute.delete = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: execute.url(args, options),
    method: 'delete',
})

/**
* @see \App\Watch\Projects\Controllers\DeleteProjectController::execute
* @see Watch/Projects/Controllers/DeleteProjectController.php:22
* @route '/projects/{project}'
*/
const executeForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: execute.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Watch\Projects\Controllers\DeleteProjectController::execute
* @see Watch/Projects/Controllers/DeleteProjectController.php:22
* @route '/projects/{project}'
*/
executeForm.delete = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: execute.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

execute.form = executeForm

const DeleteProjectController = { execute }

export default DeleteProjectController