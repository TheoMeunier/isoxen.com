import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Watch\Projects\Controllers\EditProjectController::execute
* @see Watch/Projects/Controllers/EditProjectController.php:23
* @route '/projects/{project}'
*/
export const execute = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: execute.url(args, options),
    method: 'put',
})

execute.definition = {
    methods: ["put"],
    url: '/projects/{project}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Watch\Projects\Controllers\EditProjectController::execute
* @see Watch/Projects/Controllers/EditProjectController.php:23
* @route '/projects/{project}'
*/
execute.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { project: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            project: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        project: typeof args.project === 'object'
        ? args.project.id
        : args.project,
    }

    return execute.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Watch\Projects\Controllers\EditProjectController::execute
* @see Watch/Projects/Controllers/EditProjectController.php:23
* @route '/projects/{project}'
*/
execute.put = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: execute.url(args, options),
    method: 'put',
})

/**
* @see \App\Watch\Projects\Controllers\EditProjectController::execute
* @see Watch/Projects/Controllers/EditProjectController.php:23
* @route '/projects/{project}'
*/
const executeForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: execute.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Watch\Projects\Controllers\EditProjectController::execute
* @see Watch/Projects/Controllers/EditProjectController.php:23
* @route '/projects/{project}'
*/
executeForm.put = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: execute.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

execute.form = executeForm

const EditProjectController = { execute }

export default EditProjectController