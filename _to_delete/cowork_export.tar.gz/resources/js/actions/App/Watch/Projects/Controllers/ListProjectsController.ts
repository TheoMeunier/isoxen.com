import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Watch\Projects\Controllers\ListProjectsController::render
* @see Watch/Projects/Controllers/ListProjectsController.php:18
* @route '/projects'
*/
export const render = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: render.url(options),
    method: 'get',
})

render.definition = {
    methods: ["get","head"],
    url: '/projects',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Watch\Projects\Controllers\ListProjectsController::render
* @see Watch/Projects/Controllers/ListProjectsController.php:18
* @route '/projects'
*/
render.url = (options?: RouteQueryOptions) => {
    return render.definition.url + queryParams(options)
}

/**
* @see \App\Watch\Projects\Controllers\ListProjectsController::render
* @see Watch/Projects/Controllers/ListProjectsController.php:18
* @route '/projects'
*/
render.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: render.url(options),
    method: 'get',
})

/**
* @see \App\Watch\Projects\Controllers\ListProjectsController::render
* @see Watch/Projects/Controllers/ListProjectsController.php:18
* @route '/projects'
*/
render.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: render.url(options),
    method: 'head',
})

/**
* @see \App\Watch\Projects\Controllers\ListProjectsController::render
* @see Watch/Projects/Controllers/ListProjectsController.php:18
* @route '/projects'
*/
const renderForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: render.url(options),
    method: 'get',
})

/**
* @see \App\Watch\Projects\Controllers\ListProjectsController::render
* @see Watch/Projects/Controllers/ListProjectsController.php:18
* @route '/projects'
*/
renderForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: render.url(options),
    method: 'get',
})

/**
* @see \App\Watch\Projects\Controllers\ListProjectsController::render
* @see Watch/Projects/Controllers/ListProjectsController.php:18
* @route '/projects'
*/
renderForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: render.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

render.form = renderForm

const ListProjectsController = { render }

export default ListProjectsController