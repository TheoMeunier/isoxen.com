import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Watch\Projects\Controllers\ShowProjectController::render
* @see Watch/Projects/Controllers/ShowProjectController.php:35
* @route '/projects/{project}'
*/
export const render = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: render.url(args, options),
    method: 'get',
})

render.definition = {
    methods: ["get","head"],
    url: '/projects/{project}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Watch\Projects\Controllers\ShowProjectController::render
* @see Watch/Projects/Controllers/ShowProjectController.php:35
* @route '/projects/{project}'
*/
render.url = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { project: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            project: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        project: typeof args.project === 'object'
        ? args.project.id
        : args.project,
    }

    return render.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Watch\Projects\Controllers\ShowProjectController::render
* @see Watch/Projects/Controllers/ShowProjectController.php:35
* @route '/projects/{project}'
*/
render.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: render.url(args, options),
    method: 'get',
})

/**
* @see \App\Watch\Projects\Controllers\ShowProjectController::render
* @see Watch/Projects/Controllers/ShowProjectController.php:35
* @route '/projects/{project}'
*/
render.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: render.url(args, options),
    method: 'head',
})

/**
* @see \App\Watch\Projects\Controllers\ShowProjectController::render
* @see Watch/Projects/Controllers/ShowProjectController.php:35
* @route '/projects/{project}'
*/
const renderForm = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: render.url(args, options),
    method: 'get',
})

/**
* @see \App\Watch\Projects\Controllers\ShowProjectController::render
* @see Watch/Projects/Controllers/ShowProjectController.php:35
* @route '/projects/{project}'
*/
renderForm.get = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: render.url(args, options),
    method: 'get',
})

/**
* @see \App\Watch\Projects\Controllers\ShowProjectController::render
* @see Watch/Projects/Controllers/ShowProjectController.php:35
* @route '/projects/{project}'
*/
renderForm.head = (args: { project: number | { id: number } } | [project: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: render.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

render.form = renderForm

const ShowProjectController = { render }

export default ShowProjectController