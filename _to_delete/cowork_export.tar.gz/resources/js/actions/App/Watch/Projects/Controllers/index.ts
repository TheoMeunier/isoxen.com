import ListProjectsController from './ListProjectsController'
import CreateProjectController from './CreateProjectController'
import ShowProjectController from './ShowProjectController'
import EditProjectController from './EditProjectController'
import DeleteProjectController from './DeleteProjectController'

const Controllers = {
    ListProjectsController: Object.assign(ListProjectsController, ListProjectsController),
    CreateProjectController: Object.assign(CreateProjectController, CreateProjectController),
    ShowProjectController: Object.assign(ShowProjectController, ShowProjectController),
    EditProjectController: Object.assign(EditProjectController, EditProjectController),
    DeleteProjectController: Object.assign(DeleteProjectController, DeleteProjectController),
}

export default Controllers