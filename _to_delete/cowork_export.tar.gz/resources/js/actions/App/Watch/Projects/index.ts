import Controllers from './Controllers'

const Projects = {
    Controllers: Object.assign(Controllers, Controllers),
}

export default Projects