import Projects from './Projects'
import Ingestion from './Ingestion'

const Watch = {
    Projects: Object.assign(Projects, Projects),
    Ingestion: Object.assign(Ingestion, Ingestion),
}

export default Watch