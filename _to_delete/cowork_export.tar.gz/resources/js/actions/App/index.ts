import Auth from './Auth'
import Watch from './Watch'

const App = {
    Auth: Object.assign(Auth, Auth),
    Watch: Object.assign(Watch, Watch),
}

export default App