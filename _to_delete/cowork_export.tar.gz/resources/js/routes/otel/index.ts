import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Watch\Ingestion\Controllers\IngestTracesController::traces
* @see Watch/Ingestion/Controllers/IngestTracesController.php:16
* @route '/v1/traces'
*/
export const traces = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: traces.url(options),
    method: 'post',
})

traces.definition = {
    methods: ["post"],
    url: '/v1/traces',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Watch\Ingestion\Controllers\IngestTracesController::traces
* @see Watch/Ingestion/Controllers/IngestTracesController.php:16
* @route '/v1/traces'
*/
traces.url = (options?: RouteQueryOptions) => {
    return traces.definition.url + queryParams(options)
}

/**
* @see \App\Watch\Ingestion\Controllers\IngestTracesController::traces
* @see Watch/Ingestion/Controllers/IngestTracesController.php:16
* @route '/v1/traces'
*/
traces.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: traces.url(options),
    method: 'post',
})

/**
* @see \App\Watch\Ingestion\Controllers\IngestTracesController::traces
* @see Watch/Ingestion/Controllers/IngestTracesController.php:16
* @route '/v1/traces'
*/
const tracesForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: traces.url(options),
    method: 'post',
})

/**
* @see \App\Watch\Ingestion\Controllers\IngestTracesController::traces
* @see Watch/Ingestion/Controllers/IngestTracesController.php:16
* @route '/v1/traces'
*/
tracesForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: traces.url(options),
    method: 'post',
})

traces.form = tracesForm

/**
* @see \App\Watch\Ingestion\Controllers\IngestMetricsController::metrics
* @see Watch/Ingestion/Controllers/IngestMetricsController.php:16
* @route '/v1/metrics'
*/
export const metrics = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: metrics.url(options),
    method: 'post',
})

metrics.definition = {
    methods: ["post"],
    url: '/v1/metrics',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Watch\Ingestion\Controllers\IngestMetricsController::metrics
* @see Watch/Ingestion/Controllers/IngestMetricsController.php:16
* @route '/v1/metrics'
*/
metrics.url = (options?: RouteQueryOptions) => {
    return metrics.definition.url + queryParams(options)
}

/**
* @see \App\Watch\Ingestion\Controllers\IngestMetricsController::metrics
* @see Watch/Ingestion/Controllers/IngestMetricsController.php:16
* @route '/v1/metrics'
*/
metrics.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: metrics.url(options),
    method: 'post',
})

/**
* @see \App\Watch\Ingestion\Controllers\IngestMetricsController::metrics
* @see Watch/Ingestion/Controllers/IngestMetricsController.php:16
* @route '/v1/metrics'
*/
const metricsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: metrics.url(options),
    method: 'post',
})

/**
* @see \App\Watch\Ingestion\Controllers\IngestMetricsController::metrics
* @see Watch/Ingestion/Controllers/IngestMetricsController.php:16
* @route '/v1/metrics'
*/
metricsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: metrics.url(options),
    method: 'post',
})

metrics.form = metricsForm

/**
* @see \App\Watch\Ingestion\Controllers\IngestLogsController::logs
* @see Watch/Ingestion/Controllers/IngestLogsController.php:16
* @route '/v1/logs'
*/
export const logs = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logs.url(options),
    method: 'post',
})

logs.definition = {
    methods: ["post"],
    url: '/v1/logs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Watch\Ingestion\Controllers\IngestLogsController::logs
* @see Watch/Ingestion/Controllers/IngestLogsController.php:16
* @route '/v1/logs'
*/
logs.url = (options?: RouteQueryOptions) => {
    return logs.definition.url + queryParams(options)
}

/**
* @see \App\Watch\Ingestion\Controllers\IngestLogsController::logs
* @see Watch/Ingestion/Controllers/IngestLogsController.php:16
* @route '/v1/logs'
*/
logs.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logs.url(options),
    method: 'post',
})

/**
* @see \App\Watch\Ingestion\Controllers\IngestLogsController::logs
* @see Watch/Ingestion/Controllers/IngestLogsController.php:16
* @route '/v1/logs'
*/
const logsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: logs.url(options),
    method: 'post',
})

/**
* @see \App\Watch\Ingestion\Controllers\IngestLogsController::logs
* @see Watch/Ingestion/Controllers/IngestLogsController.php:16
* @route '/v1/logs'
*/
logsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: logs.url(options),
    method: 'post',
})

logs.form = logsForm

const otel = {
    traces: Object.assign(traces, traces),
    metrics: Object.assign(metrics, metrics),
    logs: Object.assign(logs, logs),
}

export default otel